- This font is FULL VERSION and FOR PERSONAL USE ONLY. COMMERCIAL USE IS NOT ALLOWED!

- Here's the link to buy a commercial license:
https://www.creativefabrica.com/designer/sakti-avellin/

- For Corporate use, you must purchase a Corporate license
https://saktiavellin.gumroad.com/

- If you require a special license, please contact us at
dramasuara@gmail.com

- Every donation is greatly appreciated. Paypal account for donations: paypal.me/SaktiAvellin

Please visit our store for more amazing fonts: https://www.uplabs.com/drama Suara


Follow our instagram for updates : @saktiavllns_

Thank You.